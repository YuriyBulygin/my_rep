﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button_Generate_Matrix_Click(object sender, EventArgs e)
        {
            fill_array();
        }


          public void fill_array ()
        {
            int row = Convert.ToInt32(TextBox_Row.Text);
            int column = Convert.ToInt32(TextBox_Column.Text);
            Random rnd = new Random();
            Stopwatch SW = new Stopwatch();
            int[,] MyArray = new int[row, column];
            MyMatrix1.ColumnCount = column;
            MyMatrix1.RowCount = row;            
            SW.Start();
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    MyArray[i, j] = rnd.Next(1, 100);
                    MyMatrix1[i,j].Value = MyArray[i, j].ToString();     
                }
            }
            SW.Stop();
            TimeSpan ts = SW.Elapsed;
            Label_Not_Parallel.Text = ts.TotalMilliseconds.ToString() + "мс";
            Label_Not_Parallel.Visible = true;
            SW.Reset();
            MyMatrix2.ColumnCount = column;
            MyMatrix2.RowCount = row;
            SW.Start();
            Parallel.For (0, row, i =>
            {               
                for (int j = 0; j < column; j++)
                {
                    MyArray[i, j] = rnd.Next(1, 100);
                    MyMatrix2[i,j].Value = MyArray[i, j].ToString();     
                }
            }
            );
            SW.Stop();
            ts = SW.Elapsed;
            Label_Parallel.Text = ts.TotalMilliseconds.ToString() + "мс";
            Label_Parallel.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        
        }

        private void CheckBox_ShowMatrix_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckBox_ShowMatrix.Checked == true)
            {
                MyMatrix1.Visible = true;
                MyMatrix2.Visible = true;
            }
            else
            {
                MyMatrix1.Visible = false;
                MyMatrix2.Visible = false;
            }
        }
    }
}

