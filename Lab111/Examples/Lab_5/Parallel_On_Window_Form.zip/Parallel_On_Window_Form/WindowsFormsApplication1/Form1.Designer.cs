﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.MyMatrix2 = new System.Windows.Forms.DataGridView();
            this.MyMatrix1 = new System.Windows.Forms.DataGridView();
            this.Button_Generate_Matrix = new System.Windows.Forms.Button();
            this.CheckBox_ShowMatrix = new System.Windows.Forms.CheckBox();
            this.TextBox_Row = new System.Windows.Forms.TextBox();
            this.TextBox_Column = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Label_Not_Parallel = new System.Windows.Forms.Label();
            this.Label_Parallel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.MyMatrix2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MyMatrix1)).BeginInit();
            this.SuspendLayout();
            // 
            // MyMatrix2
            // 
            this.MyMatrix2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MyMatrix2.Location = new System.Drawing.Point(12, 301);
            this.MyMatrix2.Name = "MyMatrix2";
            this.MyMatrix2.Size = new System.Drawing.Size(433, 150);
            this.MyMatrix2.TabIndex = 0;
            // 
            // MyMatrix1
            // 
            this.MyMatrix1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MyMatrix1.Location = new System.Drawing.Point(12, 124);
            this.MyMatrix1.Name = "MyMatrix1";
            this.MyMatrix1.Size = new System.Drawing.Size(433, 150);
            this.MyMatrix1.TabIndex = 1;
            // 
            // Button_Generate_Matrix
            // 
            this.Button_Generate_Matrix.Location = new System.Drawing.Point(13, 56);
            this.Button_Generate_Matrix.Name = "Button_Generate_Matrix";
            this.Button_Generate_Matrix.Size = new System.Drawing.Size(239, 23);
            this.Button_Generate_Matrix.TabIndex = 2;
            this.Button_Generate_Matrix.Text = "Сгенерировать матрицы";
            this.Button_Generate_Matrix.UseVisualStyleBackColor = true;
            this.Button_Generate_Matrix.Click += new System.EventHandler(this.Button_Generate_Matrix_Click);
            // 
            // CheckBox_ShowMatrix
            // 
            this.CheckBox_ShowMatrix.AutoSize = true;
            this.CheckBox_ShowMatrix.Checked = true;
            this.CheckBox_ShowMatrix.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CheckBox_ShowMatrix.Location = new System.Drawing.Point(451, 11);
            this.CheckBox_ShowMatrix.Name = "CheckBox_ShowMatrix";
            this.CheckBox_ShowMatrix.Size = new System.Drawing.Size(136, 17);
            this.CheckBox_ShowMatrix.TabIndex = 3;
            this.CheckBox_ShowMatrix.Text = "Отображать матрицы";
            this.CheckBox_ShowMatrix.UseVisualStyleBackColor = true;
            this.CheckBox_ShowMatrix.CheckedChanged += new System.EventHandler(this.CheckBox_ShowMatrix_CheckedChanged);
            // 
            // TextBox_Row
            // 
            this.TextBox_Row.Location = new System.Drawing.Point(117, 13);
            this.TextBox_Row.Name = "TextBox_Row";
            this.TextBox_Row.Size = new System.Drawing.Size(100, 20);
            this.TextBox_Row.TabIndex = 4;
            this.TextBox_Row.Text = "25";
            // 
            // TextBox_Column
            // 
            this.TextBox_Column.Location = new System.Drawing.Point(345, 12);
            this.TextBox_Column.Name = "TextBox_Column";
            this.TextBox_Column.Size = new System.Drawing.Size(100, 20);
            this.TextBox_Column.TabIndex = 5;
            this.TextBox_Column.Text = "25";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(223, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Количество столбцов";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Количество строк";
            // 
            // Label_Not_Parallel
            // 
            this.Label_Not_Parallel.AutoSize = true;
            this.Label_Not_Parallel.Location = new System.Drawing.Point(13, 108);
            this.Label_Not_Parallel.Name = "Label_Not_Parallel";
            this.Label_Not_Parallel.Size = new System.Drawing.Size(24, 13);
            this.Label_Not_Parallel.TabIndex = 8;
            this.Label_Not_Parallel.Text = "asd";
            this.Label_Not_Parallel.Visible = false;
            // 
            // Label_Parallel
            // 
            this.Label_Parallel.AutoSize = true;
            this.Label_Parallel.Location = new System.Drawing.Point(13, 285);
            this.Label_Parallel.Name = "Label_Parallel";
            this.Label_Parallel.Size = new System.Drawing.Size(24, 13);
            this.Label_Parallel.TabIndex = 9;
            this.Label_Parallel.Text = "asd";
            this.Label_Parallel.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(761, 463);
            this.Controls.Add(this.Label_Parallel);
            this.Controls.Add(this.Label_Not_Parallel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TextBox_Column);
            this.Controls.Add(this.TextBox_Row);
            this.Controls.Add(this.CheckBox_ShowMatrix);
            this.Controls.Add(this.Button_Generate_Matrix);
            this.Controls.Add(this.MyMatrix1);
            this.Controls.Add(this.MyMatrix2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MyMatrix2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MyMatrix1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView MyMatrix2;
        private System.Windows.Forms.DataGridView MyMatrix1;
        private System.Windows.Forms.Button Button_Generate_Matrix;
        private System.Windows.Forms.CheckBox CheckBox_ShowMatrix;
        private System.Windows.Forms.TextBox TextBox_Row;
        private System.Windows.Forms.TextBox TextBox_Column;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Label_Not_Parallel;
        private System.Windows.Forms.Label Label_Parallel;
    }
}

