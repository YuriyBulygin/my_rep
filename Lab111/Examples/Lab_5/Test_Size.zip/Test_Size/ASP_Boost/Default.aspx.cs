﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading.Tasks;
using System.Diagnostics;

namespace WebApplication1
{
    public partial class _Default : Page
    {
        int array_column = 10;
        int array_row = 10;
        public double time_not_paralel;
        public double time_paralel;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        public void fill_array()
        {
            Random rnd = new Random();
            Stopwatch SW = new Stopwatch();
            int[,] MyArray = new int[array_column, array_row];
            //Заполнение матрицы
            SW.Start();
            for (int i = 0; i < array_row; i++)
            {
                TableRow row = new TableRow();
                for (int j = 0; j < array_column; j++)
                {
                    MyArray[i, j] = rnd.Next(1, 100);
                    TableCell cell = new TableCell();
                    cell.Text = MyArray[i, j].ToString();
                    row.Cells.Add(cell);
                }
                MyMatrix.Rows.Add(row);
            }
            SW.Stop();
            TimeSpan ts = SW.Elapsed;
            Label_Not_Paralel.Text = "Не параллельно: " + ts.TotalMilliseconds.ToString() + "мс";
            SW.Reset();
            //умножение матрицы не паралельно на 2
            SW.Start();
            Parallel.For(0, array_row, i =>
            {
                TableRow row = new TableRow();
                for (int j = 0; j < array_column; j++)
                {
                    MyArray[i, j] = rnd.Next(1, 100);
                    TableCell cell = new TableCell();
                    cell.Text = MyArray[i, j].ToString();
                    row.Cells.Add(cell);
                }
                MyMatrix2.Rows.Add(row);
            }

            );
            SW.Stop();
            ts = SW.Elapsed;
            Label_Paralel.Text = "Параллельно: " + ts.TotalMilliseconds.ToString() + "мс";
        }

        protected void Calculate_Click(object sender, EventArgs e)
        {
            array_column = Convert.ToInt32(TextBox_Column.Text);
            array_row = Convert.ToInt32(TextBox_Row.Text);
            if (!CheckBox1.Checked)
            {
                MyMatrix2.Visible = false;
                MyMatrix.Visible = false;
            }
            else
            {
                MyMatrix2.Visible = true;
                MyMatrix.Visible = true;
            }
            fill_array();
        }
    }
}